import React,{useState} from "react";
import FanSignUp from "./FanSignUp";
import TalentSignUp from "./TalentSignUp";

const Tabs = () => {
    const [activeTab, setActiveTab] = useState("FAN SIGNUP");

//handle FAN SIGNUP click event start
  const handleFanSignUp = () => {
    setActiveTab("FAN SIGNUP");
  };
  //handle FAN SIGNUP click event end

  //handle Talnet Signup click event start
  const handleTalnetSignUp = () => {
    setActiveTab("TALENT SIGNUP");
  };
  //handle Talnet Signup click event start

  return (
    <div className="Tabs">
     <ul className="nav">
        <li className={activeTab === "FAN SIGNUP" ? "active" : ""} onClick={handleFanSignUp}>FAN SIGNUP</li>
        <li className={activeTab === "TALENT SIGNUP" ? "active" : ""} onClick={handleTalnetSignUp}>TALENT SIGNUP</li>
      </ul>
      <div className="outlet">
       {activeTab === "FAN SIGNUP"?<FanSignUp/>:<TalentSignUp/>}
      </div>
    </div>
  );
};
export default Tabs;