import React,{useState} from "react";
const TalentSignUp = () => {
     //varible declartion start     
const[formData,setformData]=useState({
    first_name:"",
    last_name:"",
    username:"",
    email:"",
    password:"",
})
const [formErrors,setformErrors]=useState({
    first_name:"",
    last_name:"",
    username:"",
    email:"",
    password:"",
})
//varible declartion end

//handle Firstname change event start
const handleFirstNameChange=(e)=>{
   let obj={...formData}
   obj.first_name=e.target.value;
    setformData(obj);
}
//handle FirstName change event end

//handle FirstName Focus Event start
const handleFirstNameFocus=(e)=>{
    if(e.target.value==""){
        let obj={...formErrors}
   obj.first_name="Please Enter First Name";
    setformErrors(obj);
    }

}
//handle FirstName Focus Event end

//handle lastname change event start
const handleLastNameChange=(e)=>{
    let obj={...formData}
   obj.last_name=e.target.value;
    setformData(obj);
}
//handle lastName change event end

//handle lastname focus event start
const handlelastNameFocus=(e)=>{
    if(e.target.value==""){
        if(e.target.value==""){
            let obj={...formErrors}
       obj.last_name="Please Enter last Name";
        setformErrors(obj);
        }
    }
}
//handle lastname focus event end

//handle username change event start
const handleUserNameChange=(e)=>{
    let obj={...formData}
   obj.username=e.target.value;
    setformData(obj);
}
//handle username change event end

//handle username focus event start
const handleUsernameFocus=(e)=>{
        if(e.target.value==""){
            let obj={...formErrors}
       obj.username="Please Enter Username";
        setformErrors(obj);
        }
}
//handle username focus event end

//handle email change event start
const handleEmailChange=(e)=>{
        let obj={...formData}
        obj.email=e.target.value
        setformData(obj);
}
//handle email change event end

//handle email focus event start
const handleEmailFocus=(e)=>{
    if(e.target.value==""){
        if(e.target.value==""){
            let obj={...formErrors}
       obj.email="Please Enter email";
        setformErrors(obj);
        }
    }
}
//handle email focus event end

//handle password change event start
const handlePasswordChange=(e)=>{
    let obj={...formData}
   obj.password=e.target.value;
    setformData(obj);
}
//handle password change event end 

//handle password focus event start
const handlePasswordFocus=(e)=>{
    if(e.target.value==""){
        if(e.target.value==""){
            let obj={...formErrors}
       obj.password="Please Enter password";
        setformErrors(obj);
        }
    }
}
//handle password focus event end

//handle sign up click event start
const handleSignUp=()=>{
       console.log(formData);
   if(formData.first_name == "" && formData.last_name=="" && formData.username == "" && formData.email == "" && formData.password == ""){
    setformErrors({
        first_name:"Enter First Name",
        last_name:"Enter Last Name",
        username:"Enter UserName",
        email:"Enter Email",
        password:"Enter password"
    })
   }else{
    const requestOptions = {
             method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData)
            };
            fetch('http://wren.in:3200/api/sign-up/talent', requestOptions).then((response)=>{
                if(response.ok == true){
alert("Api sucessfully called");
                }else{
                    alert("Api not successfully called")
                }
            }) 
           
        }        
}
//handle sign up click event end
  return (
    <div className="TalentSignUp">
     <div className="FanSignUp">
     <h3>Create Your Talent Account</h3>
     <div className="container-fluid">
     
            <div className="form-group">
            <label> First name {formData.first_name == ""?<span className="asterisk">*</span>:<></>}
                 </label>
                
                <input className="form-control" type="text" name="firstName" value={formData.first_name} onChange={handleFirstNameChange}  placeholder="First Name" onFocus={handleFirstNameFocus}/>
                {formData.first_name == ""?<span className="err">{formErrors.first_name}</span>:<></>} 
                
            </div>
            <div className="form-group">
            <label> Last name {formData.last_name == ""?<span className="asterisk">*</span>:<></>}
                 </label>
                 <input className="form-control" type="text" name="lastName" value={formData.last_name} onChange={handleLastNameChange}  placeholder="Last Name" onFocus={handlelastNameFocus}/>
                 {formData.last_name == ""?<span className="err">{formErrors.last_name}</span>:<></>}  
            </div>
            <div className="form-group">
            <label> UserName {formData.username == ""?<span className="asterisk">*</span>:<></>}
                 </label>
                 <input className="form-control" type="text" name="userName" value={formData.username} onChange={handleUserNameChange} placeholder="username" onFocus={handleUsernameFocus} /> 
                 {formData.username == ""?<span className="err">{formErrors.username}</span>:<></>}  
            </div>
            <div className="form-group">
            <label> Email {formData.email == ""?<span className="asterisk">*</span>:<></>}
                 </label>
                 <input className="form-control" type="text" name="email" value={formData.email} onChange={handleEmailChange} placeholder="email" onFocus={handleEmailFocus}/> 
                 {formData.email == ""?<span className="err">{formErrors.email}</span>:<></>}  
            </div>
            <div className="form-group">
            <label> Password {formData.password == ""?<span className="asterisk">*</span>:<></>}
                 </label>
                 <input className="form-control" type="password" name="password" value={formData.password} onChange={handlePasswordChange} placeholder="password" onFocus={handlePasswordFocus}/> 
                 {formData.password == ""?<span className="err">{formErrors.password}</span>:<></>}  
            </div>
            <div className="form-group">
                 <input  type="checkbox" name ="chk" defaultChecked={true} /> I Agree To the <b className="green">Terms & conditions </b> 
            </div>
            <div className="form-group">
             <input type="button" className="btn btn-primary" value="Sign Up"  onClick={handleSignUp}/>
           </div>
        </div>
     </div>
    </div>
  );
};
export default TalentSignUp;