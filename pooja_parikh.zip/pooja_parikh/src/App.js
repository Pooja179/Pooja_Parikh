
import './App.css';
import Tabs from "../src/components/Tabs";


function App() {
  return (
    <div className="App">
   <Tabs/>
    </div>
  );
}

export default App;
